import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api';
import Counter from '../components/Counter';

const CARDS = [
  ['pets_available', 'Pets available', '🐾', '/admin/pets'],
  ['pets_adopted', 'Adopted', '❤️', '/admin/pets'],
  ['applications_pending', 'Applications to review', '📋', '/admin/applications'],
  ['appointments_pending', 'Consultations pending', '📅', '/admin/appointments'],
  ['messages_unread', 'Unread messages', '✉️', '/admin/messages'],
  ['vets', 'Veterinarians', '🩺', '/admin/vets'],
];

export default function Dashboard() {
  const [stats, setStats] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api('/admin/dashboard').then(setStats).catch((e) => setError(e.message));
  }, []);

  return (
    <>
      <h1 className="admin-title">Dashboard</h1>
      {error && <div className="alert alert-error">{error}</div>}
      <div className="stat-grid">
        {CARDS.map(([key, label, icon, to]) => (
          <Link to={to} className="stat-card" key={key}>
            <span className="stat-icon">{icon}</span>
            <strong><Counter to={stats?.[key] ?? 0} /></strong>
            <small>{label}</small>
          </Link>
        ))}
      </div>

      <div className="panel">
        <div className="panel-head"><h2>Recent adoption applications</h2><Link to="/admin/applications">View all →</Link></div>
        {stats?.recent_applications?.length ? (
          <ul className="recent">
            {stats.recent_applications.map((a) => (
              <li key={a.id}>
                <span><b>{a.full_name}</b> wants to adopt <b>{a.pet || 'a pet'}</b></span>
                <span className={`badge badge-${a.status}`}>{a.status}</span>
              </li>
            ))}
          </ul>
        ) : (
          <p className="muted">No applications yet.</p>
        )}
      </div>
    </>
  );
}
