import { useCallback, useEffect, useRef, useState } from "react";
import { Navigate, useParams } from "react-router-dom";
import { api } from "../api";
import { RESOURCES } from "./resources";
import ResourceForm from "./ResourceForm";

function Cell({ value }) {
  if (value && typeof value === "object") {
    if (value.type === "img")
      return <img className="thumb" src={value.src} alt="" />;
    if (value.type === "badge")
      return (
        <span className={`badge badge-${value.value}`}>{value.value}</span>
      );
  }
  return value ?? "—";
}

/**
 * Keyed by resource so every sidebar link gets a fresh page (fresh state).
 * Without the key, the previous module's rows were rendered with the new module's columns,
 * which crashed the page until you refreshed.
 */
export default function ResourcePage() {
  const { resource } = useParams();
  return <ResourceView key={resource} resource={resource} />;
}

function ResourceView({ resource }) {
  const def = RESOURCES[resource];
  const [rows, setRows] = useState(null);
  const [error, setError] = useState("");
  const [editing, setEditing] = useState(null); // row | {} (new) | null
  const [viewing, setViewing] = useState(null);

  const alive = useRef(true);
  useEffect(() => {
    alive.current = true;
    return () => {
      alive.current = false;
    };
  }, []);

  const load = useCallback(() => {
    setRows(null);
    setError("");
    api(`/admin/${resource}`)
      .then((data) => alive.current && setRows(Array.isArray(data) ? data : []))
      .catch((e) => alive.current && setError(e.message));
  }, [resource]);

  useEffect(() => {
    if (def) load();
  }, [def, load]);

  if (!def) return <Navigate to="/admin" replace />;

  const patch = async (row, body) => {
    try {
      const updated = await api(`/admin/${resource}/${row.id}`, {
        method: "PUT",
        body,
      });
      setRows((rs) => rs.map((r) => (r.id === row.id ? updated : r)));
      if (resource === "applications" && body.status === "approved") load(); // pet became adopted
    } catch (e) {
      setError(e.message);
    }
  };

  const remove = async (row) => {
    if (!window.confirm("Delete this entry? This cannot be undone.")) return;
    try {
      await api(`/admin/${resource}/${row.id}`, { method: "DELETE" });
      setRows((rs) => rs.filter((r) => r.id !== row.id));
    } catch (e) {
      setError(e.message);
    }
  };

  const inbox = def.kind === "inbox";

  return (
    <>
      <div className="admin-head">
        <h1 className="admin-title">{def.title}</h1>
        {!inbox && (
          <button className="btn btn-primary" onClick={() => setEditing({})}>
            ＋ Add new
          </button>
        )}
      </div>
      {error && <div className="alert alert-error">{error}</div>}
      {!rows && !error && <p className="muted">Loading…</p>}
      {rows && rows.length === 0 && (
        <div className="panel empty">🐾 Nothing here yet.</div>
      )}

      {rows && rows.length > 0 && (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                {def.columns.map((c) => (
                  <th key={c.label}>{c.label}</th>
                ))}
                {def.statusField && <th>Status</th>}
                {def.readField && <th>Read</th>}
                <th className="actions-col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr
                  key={row.id}
                  className={
                    def.readField && !row[def.readField] ? "unread" : ""
                  }
                >
                  {def.columns.map((c) => (
                    <td key={c.label} data-label={c.label}>
                      <Cell value={c.render ? c.render(row) : row[c.key]} />
                    </td>
                  ))}
                  {def.statusField && (
                    <td data-label="Status">
                      <select
                        className={`status-select badge-${row[def.statusField]}`}
                        value={row[def.statusField]}
                        onChange={(e) =>
                          patch(row, { [def.statusField]: e.target.value })
                        }
                      >
                        {def.statuses.map((s) => (
                          <option key={s}>{s}</option>
                        ))}
                      </select>
                    </td>
                  )}
                  {def.readField && (
                    <td data-label="Read">
                      <input
                        type="checkbox"
                        checked={!!row[def.readField]}
                        onChange={(e) =>
                          patch(row, { [def.readField]: e.target.checked })
                        }
                        aria-label="Mark as read"
                      />
                    </td>
                  )}
                  <td className="actions" data-label="Actions">
                    {inbox ? (
                      <button
                        className="link-btn"
                        onClick={() => {
                          setViewing(row);
                          if (def.readField && !row[def.readField])
                            patch(row, { [def.readField]: true });
                        }}
                      >
                        View
                      </button>
                    ) : (
                      <button
                        className="link-btn"
                        onClick={() => setEditing(row)}
                      >
                        Edit
                      </button>
                    )}
                    <button
                      className="link-btn danger"
                      onClick={() => remove(row)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {editing && (
        <ResourceForm
          resource={resource}
          def={def}
          row={editing.id ? editing : null}
          onClose={() => setEditing(null)}
          onSaved={() => {
            setEditing(null);
            load();
          }}
        />
      )}

      {viewing && (
        <div
          className="modal-backdrop"
          onMouseDown={(e) => e.target === e.currentTarget && setViewing(null)}
        >
          <div className="modal">
            <button
              className="modal-close"
              onClick={() => setViewing(null)}
              aria-label="Close"
            >
              ×
            </button>
            <h2>{def.title}</h2>
            <dl className="details">
              {def.details(viewing).map(([k, v]) => (
                <div key={k}>
                  <dt>{k}</dt>
                  <dd>{v}</dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
      )}
    </>
  );
}
