import { useState } from 'react';
import { NavLink, Outlet, Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth';
import { RESOURCES, NAV_ORDER } from './resources';

export default function AdminLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const signOut = async () => {
    await logout();
    navigate('/admin/login');
  };

  return (
    <div className={`admin ${open ? 'menu-open' : ''}`}>
      <aside className="admin-side">
        <Link to="/admin" className="admin-brand"><img src="/images/LOGO/paas-mark-cream.png" alt="" /><span>Paw Avenue Sanctuary<small>Admin</small></span></Link>
        <nav onClick={() => setOpen(false)}>
          <NavLink to="/admin" end>📊 Dashboard</NavLink>
          {NAV_ORDER.map((k) => <NavLink key={k} to={`/admin/${k}`}>{RESOURCES[k].icon} {RESOURCES[k].label}</NavLink>)}
        </nav>
        <div className="admin-side-foot">
          <a href="/" target="_blank" rel="noreferrer">🌐 View website</a>
          <button onClick={signOut}>⎋ Sign out</button>
        </div>
      </aside>
      {open && <div className="admin-scrim" onClick={() => setOpen(false)} />}
      <div className="admin-main">
        <header className="admin-top">
          <button className="admin-burger" onClick={() => setOpen(true)} aria-label="Open menu">☰</button>
          <span className="admin-hello">Hello, {user.name} 👋</span>
        </header>
        <div className="admin-content"><Outlet /></div>
      </div>
    </div>
  );
}
